from __future__ import unicode_literals

from django.apps import AppConfig


class RandomWordsAppConfig(AppConfig):
    name = 'random_words_app'
