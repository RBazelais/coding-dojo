function centerVertically() {
	$("#wrapper").offset({
		left: $("#wrapper").offset().left,
		top: $(window).innerHeight() / 2 - $("#wrapper").outerHeight() / 2
	});

	$(".option-text-container").each(function() {
		$(this).offset({
			left: $(this).offset().left,
			top: $(this).parent().offset().top + $(this).parent().innerHeight() / 2 - $(this).outerHeight() / 2
		});
	});
}

$(function() {
	centerVertically();

	$(window).resize(function() {
		centerVertically();
	});

	$("#house").click(function() { window.location = "/" });
	$("#cave").click(function() { window.location = "/" });
	$("#farm").click(function() { window.location = "/" });
	$("#casino").click(function() { window.location = "/" });
});